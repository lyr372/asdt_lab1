# 本地部署与运行说明

## 运行目标
- 使用脚本 `apps\minions-doc-search\local_rag_document_search.py` 完成：
  - 从用户查询自动生成关键词与权重
  - 基于 BM25 在本地目录检索 Top-K 文档
  - 以检索到的文档为上下文，由本地模型给出结构化回答（答案/引用/置信度）

## 环境要求
- Windows 10/11
- Python 3.11（不建议 3.13）
- 已安装并可运行的 `Ollama`（https://ollama.com/download）

## 安装与准备（Windows）
1) 创建并启用虚拟环境
```
python -m venv .venv
.\.venv\Scripts\activate
```

2) 安装依赖（精简版）
```
pip install -r requirements.txt
```

3) 启动本地模型服务并拉取模型
```
ollama serve
ollama pull gemma3:4b
```
模型可更换为 `llama3.2` 等本地可用模型。

## 目录放置建议
- 将要检索的文本文件放入一个目录（例如 `./docs`），支持 `.md .txt .py` 等常见文本类型。

## 运行示例：本地文档检索（BM25）
```
python apps\minions-doc-search\local_rag_document_search.py --retriever bm25 --documents-path .\docs --model_name gemma3:4b --top-k 3 --query "这些文档讨论了哪些主要主题？"
```
脚本流程：
- 用本地模型从查询中提取关键词与权重
- 使用 BM25 检索并输出 Top-K 文档
- 以这些文档为上下文由本地模型生成结构化回答

## 可选扩展
- 语义检索（`--retriever embedding`）：
```
pip install sentence-transformers faiss-cpu
python apps\minions-doc-search\local_rag_document_search.py --retriever embedding --documents-path .\docs --model_name gemma3:4b --top-k 3 --query "项目关键技术点是什么？"
```
- 使用 `ollama` 的嵌入检索（`--retriever ollama`）无需额外安装，但需 `ollama` 运行且有相应嵌入模型。

## 常见问题
- 无法连接 `ollama`：确保先运行 `ollama serve`，并已拉取所需模型。
- 语义检索缺库：安装 `sentence-transformers` 与 `faiss-cpu`，或改用 `bm25`。
- Python 版本冲突：优选 3.11，新建干净虚拟环境重试。

## 维护建议
- 保留 `minions\` 与 `apps\minions-doc-search\` 两块核心代码
- 依赖按需安装，确保最小可运行与易维护

- [本地部署与运行说明](#本地部署与运行说明)
  - [运行目标](#运行目标)
  - [环境要求](#环境要求)
  - [安装与准备（Windows）](#安装与准备windows)
  - [目录放置建议](#目录放置建议)
  - [运行示例：本地文档检索（BM25）](#运行示例本地文档检索bm25)
  - [可选扩展](#可选扩展)
  - [常见问题](#常见问题)
  - [维护建议](#维护建议)
